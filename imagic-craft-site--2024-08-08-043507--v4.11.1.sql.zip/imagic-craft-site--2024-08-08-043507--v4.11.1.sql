-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_tjswluyfkpwjqpgwzrshtftkdvucninkbhew` (`ownerId`),
  CONSTRAINT `fk_tjswluyfkpwjqpgwzrshtftkdvucninkbhew` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xtelljvuwkbhrhyyfyfzjduzgxkbkyxlszfp` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_koxewurgxffgrbnarzxhxcvcslyscdwxaiti` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_rwhvhvaiwnwpuxhayksjgoigeooffsnkiqat` (`dateRead`),
  KEY `fk_bpfiwyvorucfajxbfhfuqxmlxurqnckmnqcv` (`pluginId`),
  CONSTRAINT `fk_bpfiwyvorucfajxbfhfuqxmlxurqnckmnqcv` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ukgfvasygkuvecziqtdzxvisslvoeuwvlhuf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sagohmiqvmqxnsnggiqmnwtwakjulgayeqpf` (`sessionId`,`volumeId`),
  KEY `idx_xptricpbrpsktkskjrcqhawysmohetipyozp` (`volumeId`),
  CONSTRAINT `fk_juwhpwfojjrkowraohheyonecnahtdbhxyic` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rupvblalbjmfiesjshkfnumtmlivuuiifjbf` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bysinyajlgjutwdyyemukvsobeuucbhlumwm` (`filename`,`folderId`),
  KEY `idx_gkglwkygdlxnrqmcypowgukewqlwaxadxnoc` (`folderId`),
  KEY `idx_crnvznjbfntlbajmowfqvulxslgsymohrapd` (`volumeId`),
  KEY `fk_nxiaicmepboymxnpqcumidljzwjussowfzhi` (`uploaderId`),
  CONSTRAINT `fk_nxiaicmepboymxnpqcumidljzwjussowfzhi` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wletkwhfhwezrkaelrujbbrynndkuytayjht` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xuqrntpmgxeugqcdzqtfghougbvawjkhswyz` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yiolyldjstcrscvbqeskbelexpmkplwgdrtg` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_asveteoqkvjsnizhchaipsnhqwapegezuzve` (`groupId`),
  KEY `fk_fhoatgnsotzbuodogskxhlirupejxxzgbuij` (`parentId`),
  CONSTRAINT `fk_fhoatgnsotzbuodogskxhlirupejxxzgbuij` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rfyeknuzocdahwtsjjklbxngcqyohjqndokz` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xblmuorfkwdnacnzqqcwevvjiuylbvcesdse` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_flckplwkrmiawkupoijrquriakcnmmskyesb` (`name`),
  KEY `idx_hsbvnesoutqxqfrnkkejrlnsvegpsuhdcple` (`handle`),
  KEY `idx_ahdygjejitingggdlrsjashfjqmfalcpooqi` (`structureId`),
  KEY `idx_qjxflotoykkjykkwgjgjckidyqovwskbkjja` (`fieldLayoutId`),
  KEY `idx_xyfugdaovwmeiajbhxxfuuhlhalfozlkigjo` (`dateDeleted`),
  CONSTRAINT `fk_tgbvetovmfnstrgoostpgeabzqazxxyswmpm` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_znqsrshvkljjueekseknlppjeqdwvtsfrbjj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xlymnwfksaqedkkzzxlhfjxozrcepmkjmtdm` (`groupId`,`siteId`),
  KEY `idx_xvxcdscqksjwagncnarbwjfbnjdkzdytrhum` (`siteId`),
  CONSTRAINT `fk_ghuneejcgilrlpiyaribqkoghgqltbrmgdos` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vuedutznrhdcncmwdwbjhptvbrnlxhepizmu` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_npqtcxgskzxpxvygytogmjxvlcbxzfmipwoc` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_zzlilravpzzllxezmmbzoueginsolnrcnqry` (`siteId`),
  KEY `fk_euxqomquzstqfrmlksjlfqhlxchzjwuvlpgq` (`userId`),
  CONSTRAINT `fk_euxqomquzstqfrmlksjlfqhlxchzjwuvlpgq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_vwjnrwhehvkpadffpbxmystizapdcdnzbasi` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zzlilravpzzllxezmmbzoueginsolnrcnqry` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_vlfrwlcchchpyarwwczrszpjtqwprelhxjko` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_efuzuqhmohormmxqghwozrqcijrpxqgglqpx` (`siteId`),
  KEY `fk_sjjodnlzpmqpuoampagwaoaufkesekfjfqgt` (`fieldId`),
  KEY `fk_nqggrhzztfpensesztaonhyxxonepgwymxej` (`userId`),
  CONSTRAINT `fk_efuzuqhmohormmxqghwozrqcijrpxqgglqpx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nqggrhzztfpensesztaonhyxxonepgwymxej` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sjjodnlzpmqpuoampagwaoaufkesekfjfqgt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_txprcusziagyokzfgjakhvwwiuixhugcwyxq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_myomitbtbkluygkysimsdrcdhzmwbcamygdl` (`elementId`,`siteId`),
  KEY `idx_orsounkyabscuwdmvihjaajkerhrftvlboic` (`siteId`),
  KEY `idx_laxnckndwrswjibbtvnjwoadhzpokoagxkqf` (`title`),
  CONSTRAINT `fk_hfejgmzandyojvcxqowvusysrdqdzcoufula` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jxcoorsztfoyuiqgsmxuhlxkvezmaxxzjugm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_sxdhxrvhfmsgpfxbesuxshvavensbflovcky` (`userId`),
  CONSTRAINT `fk_sxdhxrvhfmsgpfxbesuxshvavensbflovcky` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ubcbkncicnbyvnbpshlgbnfuqsnzuzkqpbhd` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_uyqrbccdjjijaqnscrnkchqndjfrrqtntdwi` (`creatorId`,`provisional`),
  KEY `idx_vfeopjjavbdagdwuupzohwrmxfzldqsqcqvi` (`saved`),
  KEY `fk_tgckbvhqzjlotlnfydywbnxigdpjzzouxxeq` (`canonicalId`),
  CONSTRAINT `fk_axgbalbqqbisuvjsjljtgwflxnomrgictzfk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tgckbvhqzjlotlnfydywbnxigdpjzzouxxeq` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_zsxqsbvvlwkgblvphcwesmqgvuzlauznhftu` (`elementId`,`timestamp`,`userId`),
  KEY `fk_ylhvqnjgerldzlonqkmltebvwhsoyscjpcqy` (`userId`),
  KEY `fk_iwhaprrigtjolqvjjnufcfjnwbvgebistbxu` (`siteId`),
  KEY `fk_fruymyjwpzgjlbsqxgyvccgqjlriaezqloig` (`draftId`),
  CONSTRAINT `fk_fruymyjwpzgjlbsqxgyvccgqjlriaezqloig` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iwhaprrigtjolqvjjnufcfjnwbvgebistbxu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_udxyschuoyurbvqbasuomrlcxmtgsikncoqb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ylhvqnjgerldzlonqkmltebvwhsoyscjpcqy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iqawkfctofenaaqarkqhnwjbegdhocktyrbx` (`dateDeleted`),
  KEY `idx_gonfsgziimozgzrnxzxtrrqkmfyffasqxirq` (`fieldLayoutId`),
  KEY `idx_zmrpzzisrvwhpvrcharnoffspokvzyzxlalp` (`type`),
  KEY `idx_oynsnsuuhqnfftnkpyxyhbojhdkvskggjqpv` (`enabled`),
  KEY `idx_fpwfjexpspneixndaieusorstyqjlsxzrtxe` (`canonicalId`),
  KEY `idx_xjtnyhopmepoebggytwfcbrgbbcnrcufgvny` (`archived`,`dateCreated`),
  KEY `idx_ncdbrmijdkngdmxeuijbhwyngegcusfgbweq` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_hsmvogqfyfovqsptxvibnwgrkcnamvunfgko` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_vuzjbgdtmcjajhaxwnlepcwmtuuxfwmhothl` (`draftId`),
  KEY `fk_ayehwgerfxlnevncrsqvzfmlghwpsfjeqbbh` (`revisionId`),
  CONSTRAINT `fk_ayehwgerfxlnevncrsqvzfmlghwpsfjeqbbh` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gtdhvtrxhughcljwbhmrswfvhqozfmmoocau` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hhiumuhwmvisqpjhitkdfqpnsnxhzamlhxfs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vuzjbgdtmcjajhaxwnlepcwmtuuxfwmhothl` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ujufqddqzgexdepagbfihcdvujtrfdsuteae` (`elementId`,`siteId`),
  KEY `idx_asuqvvacvvihlvxeilwtrfgtcumgutbbwxua` (`siteId`),
  KEY `idx_egkvxteomribfkucguhwvfvhvmwtrqpnsaxk` (`slug`,`siteId`),
  KEY `idx_uxtizqfwioqpttpinwbnbmvvygndyahooqgi` (`enabled`),
  KEY `idx_rvhdmdngdirfnpcdcjbffnirmffhqykktvil` (`uri`,`siteId`),
  CONSTRAINT `fk_ckryaqzowkbamhqybjsymuifwdqkqtbrzkwo` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zsocoqkugwkgejyujfesefhomnidpfpzwmve` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zuoekfwgitzljedhyehshrvssgtsjrbbfcwn` (`postDate`),
  KEY `idx_ysbmbqaoucbhqsyffbnokzohulcqjyjaizhe` (`expiryDate`),
  KEY `idx_fwcqvcjncafsdhndorovrmidfutijskvzsri` (`authorId`),
  KEY `idx_khythacyxsalifmuhmnhhlshvzuxcsurikrf` (`sectionId`),
  KEY `idx_pyozlgrcoscjgpbfckdgvyugoyshifkbtwaq` (`typeId`),
  KEY `fk_vmlfxiqhvuwfgjfgcktcrbfxotvbppjxualx` (`parentId`),
  CONSTRAINT `fk_aypdrbryakxayenylabjhlplofuyjlgskhvq` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bawhxntjzrkqdwysixjjhfmcjqkkgfwqfqrr` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_czknbnruetvhochsdodvdajyhogbzabguaoi` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kvqkizozxgsebtmxmcpdzbjzfsluuzjjlnmd` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vmlfxiqhvuwfgjfgcktcrbfxotvbppjxualx` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dptldsblsbnbuilnxhiqfzngqibcgqsbhcyo` (`name`,`sectionId`),
  KEY `idx_ezzofxzerdvmtlqqncnwucdjbcpyypvfoxil` (`handle`,`sectionId`),
  KEY `idx_ofadkfhtjciwdzqxacomhbujjbbkhqasbvpf` (`sectionId`),
  KEY `idx_ndrtwqucimtxtpcwrxredmurudgekzmwdrve` (`fieldLayoutId`),
  KEY `idx_wxmfoksqdyeevsokgwapqprmqhidvjrrxxde` (`dateDeleted`),
  CONSTRAINT `fk_ifskketgmbbtyzmmjqlkkeksysdbfycnxvvg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vdtwiesgxijyrkatkfnqwxvxcqodgpyohkek` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xogmmilquxitwmhmefkohhqavnguywntwhes` (`name`),
  KEY `idx_mobvzwwgobynxhrnkbjdrhhsjxfrzkogicdh` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_neyafsabiquwtrrkqcnpxccwdejkmlkaofkj` (`layoutId`,`fieldId`),
  KEY `idx_hhcdrswmlhcjmmtofuucxifyaoyfibnmqbqq` (`sortOrder`),
  KEY `idx_epamfgvwdooquommrkvntwkwufzquvfqbyus` (`tabId`),
  KEY `idx_rtogrshshoimpcbbpurhzwcvmenbgroimldx` (`fieldId`),
  CONSTRAINT `fk_ayxtrvzgfggezhvjmkwuwxcehnplsudzuljj` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_srhhkbmkmblpratvmhspjpwnxfsdjpqrxzdm` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wsuvzwqkjpeelvemvemqlumpoumofvtdfdro` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fygeaqelhnqakrafaucwutivxyejyzjkghmr` (`dateDeleted`),
  KEY `idx_jgxnsttoyxevfiuvgvjjpguxsldpvvthxgph` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sttdubbpwekqkdofousuidykqdvqfbiempqk` (`sortOrder`),
  KEY `idx_ycvznykgpxtyywyzbpksfrzodqzdgpucitqv` (`layoutId`),
  CONSTRAINT `fk_ohhxuxicownteanycybbbcupbyndqhxvezjt` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jpqezohysviekgtsiavdfunufyktpenvkbfm` (`handle`,`context`),
  KEY `idx_rohikwjyefdcpilezpkjlggdhdoruzvhnivs` (`groupId`),
  KEY `idx_ustpegqpmrpqnofluwuyrkukxhchovcnfaus` (`context`),
  CONSTRAINT `fk_bysvlyesrdxoqdcrtpmacwulhhwtvhddjbsd` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wtpblhhekvecguikerqtuzeqvczdoweaoodc` (`name`),
  KEY `idx_tjtqfudqhoyghhqqjolmpgaclllrvmtcihgo` (`handle`),
  KEY `idx_comhvcurhmyjvdqjljuuidavsuwvzwfoplqf` (`fieldLayoutId`),
  KEY `idx_ywgzpptnmrrvjkgjzggrmwgjjiwoiienlzna` (`sortOrder`),
  CONSTRAINT `fk_cspyegkznvsatnsrlnpsxvqlzmmtylvfmrzh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iwptrbtclnjdemsnppbwhwmgodevwnzcbovs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pbkmzmteaoraygcsjedczbidabwvsvcvcnuk` (`accessToken`),
  UNIQUE KEY `idx_pipsyguhddbbhdbedomadskhufcynfrzpaad` (`name`),
  KEY `fk_xgnlthlhiavaferzcxzueknbrqxpvmecprwh` (`schemaId`),
  CONSTRAINT `fk_xgnlthlhiavaferzcxzueknbrqxpvmecprwh` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gskmgfwxuwekbyuwnartrgfyalzyiquicsgr` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eelvvdkvrnuxxnhpnjeohwjipvvelowgwzrc` (`name`),
  KEY `idx_dpugrhayftfypegvdvgfvnsnxzeucfxnpbia` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ytzopfxrvuqkkangelmzelnnjyexatkdsocu` (`primaryOwnerId`),
  KEY `idx_sfgpanikmqodqwlfdawddmvqrnlteeluqfcn` (`fieldId`),
  KEY `idx_uhifybtohvkxzhpuutxaxlatulbjjxuskmio` (`typeId`),
  CONSTRAINT `fk_audziqvsdrajcklffgavejezpqruxrcarzcc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ojhhyysmliugrwaguvqyhiesmssbqhupzrtp` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uqphomigfzrorjaztndgezstqvnclykkvkwm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wppkjfbutyzasqccanwrtgnpamvslztwvupy` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_nqelfxzddoxwtmlhxcjbnmjtgojseqxioayi` (`ownerId`),
  CONSTRAINT `fk_nqelfxzddoxwtmlhxcjbnmjtgojseqxioayi` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qoxapsjgylcgdosqikyiohebniqdcudaogqm` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xfuumhtouwbeftqstgnfbvpumhrutxejnxfq` (`name`,`fieldId`),
  KEY `idx_hoaalcvyrkpvxuepphykzjpwxoyttovpjmsr` (`handle`,`fieldId`),
  KEY `idx_pxyjcqhnvzerhrdmtddmmeofqpzxpdnqnkyt` (`fieldId`),
  KEY `idx_psidwgxibmcgscuzmliuurkwfwqmwvrjcyyz` (`fieldLayoutId`),
  CONSTRAINT `fk_fljchiixsmglelfqkkaoufgynrmoalwzscfj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ooqbckscftgkijrjfwyxkccafgzbcjyojjsf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_components`
--

DROP TABLE IF EXISTS `matrixcontent_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixcontent_components` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_hero_heading_itadloce` text,
  `field_imageCarousel_heading_oczjoork` text,
  `field_imageCarousel_shortDescription_qmeakwxi` text,
  `field_hero_shortText_iqnkxidc` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bibcscsrzbgfgyxaptptufaodxmybiaebljn` (`elementId`,`siteId`),
  KEY `fk_vcsoglpsgqzovqwxquveewzldcymoxwihbdu` (`siteId`),
  CONSTRAINT `fk_toqaxiyowbuixavqrjtcgrijxxfpzncjkhng` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vcsoglpsgqzovqwxquveewzldcymoxwihbdu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_esbyzvyvspvmnjhjybfepdwrbgjdnomjgeao` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dhjasorlgyhmiirxphjmsmxuezidnyykqbom` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_mdqguuzwhqlixizzcgsfrnsyaoiczjdnxerk` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_zwuybwobarxpcjdzqpwumvvlfkskpwegbvum` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fdrmtdxbyodzyqumsadgvnoatgqiujjifllp` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_lqphvqxyipcxduupkeoobzibmggsjzktfsrr` (`sourceId`),
  KEY `idx_jdblhwypmgbrabkxnzvxhakqbfrhvknqcfev` (`targetId`),
  KEY `idx_qjdpkbdbmtlexxtkxxtacgaredqxzaxsurti` (`sourceSiteId`),
  CONSTRAINT `fk_kawllvvoqjagfwcffsgrydhxljqjplrvnqmp` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lqkvyrckepgxrizdvisrsxepidoujziexwik` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_momlkrtbugexokxjyavdfccstjjucwrosbbz` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jeysqdulonndbwpnoiqzvcioacseobymhbqp` (`canonicalId`,`num`),
  KEY `fk_qtpodfkyrdefkpvfkrhfhyymgqukeeajmsmq` (`creatorId`),
  CONSTRAINT `fk_bqspumtdespldqwchgykuzpinsivnjcnujqj` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qtpodfkyrdefkpvfkrhfhyymgqukeeajmsmq` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_bkanqlwjdldnoksmopvksgysdkfadesiftfr` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dxzxokwqofqxxdluqbekskaneieinczfwxhh` (`handle`),
  KEY `idx_gzfxyfcmlvjsvzrhmsxzjkvyhetehscveoky` (`name`),
  KEY `idx_rxohughyglyfzaykskweapapmfyhafnxlhuz` (`structureId`),
  KEY `idx_ksolszcbzagjojwepcaenaubxcmzxeuoosrp` (`dateDeleted`),
  CONSTRAINT `fk_qbjcxzahutjczhlmkdlsktnexlxtckwhitzc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rhuafvdoimanpumvwanskfplzgwahfqmatho` (`sectionId`,`siteId`),
  KEY `idx_hrvukiwcwhqhjcolpdmoapsqgtjnogqsygfr` (`siteId`),
  CONSTRAINT `fk_qcaxoynjikfgnkuqatxaxzkgnroerynjozoi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rpwkvxfbavmawbymajnoimkryrivlfgxqkqf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_akpdkxujluqidufamydiruudakvmibaqlmjq` (`uid`),
  KEY `idx_qwnaibiwymukxplbdnfcmebbxjxlynavxyhf` (`token`),
  KEY `idx_tgaoykzluvyydsqoqsvweulsugiqsotcease` (`dateUpdated`),
  KEY `idx_xdbgxedlmvzwqawimtrfckuuzvcdtibwczot` (`userId`),
  CONSTRAINT `fk_ffdlruhnbmvsjfpkxrkmwvbilgbyripbmfts` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xrvhisfobmaurtcuevskcckelaiqolynscyl` (`userId`,`message`),
  CONSTRAINT `fk_apceekzgvbgvasknusmbaymkyntljsdnoqor` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kffrxmqnikfqyuidulfvszyuvgabgtcjuhxu` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_avijlrggzxaeawlkephmusyznsizipqofbxc` (`dateDeleted`),
  KEY `idx_tjfwgejtxabwdjbbomgmrwkwuxweusztunkp` (`handle`),
  KEY `idx_udfwpixupqobuihgvsqymllsuowgicrnftgo` (`sortOrder`),
  KEY `fk_laoozinjftozzlgamtjdtqgifndvaclfjwvd` (`groupId`),
  CONSTRAINT `fk_laoozinjftozzlgamtjdtqgifndvaclfjwvd` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nxwdwvtlbindycgvrdsddpmhlqkocqboowmh` (`structureId`,`elementId`),
  KEY `idx_zmtzelfhppgpovrroaaymosaowyxzplmnruc` (`root`),
  KEY `idx_gyhvgbjrwpojbjxvqfwzohdvzwclhdpaygza` (`lft`),
  KEY `idx_izswmeeypvvtreckydeehpzeddbgduvdneov` (`rgt`),
  KEY `idx_lurnsekawcszjzqifovhsydinmsslcikehui` (`level`),
  KEY `idx_jgdtzgtspvcpvlupphsjghkiybgkpzvntbig` (`elementId`),
  CONSTRAINT `fk_wcctyhvonikeldzcxxcshnnjzhrmwaubqouu` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bqselwatoesrwvuobwaqkmsigaxsqkzpkbzx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uiscsqbcuullrbubdievetagmeiafjtsspyn` (`key`,`language`),
  KEY `idx_gruayaohykgdwrpnsoiqjsqkgifrkhrbfwzi` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vizxwythofmguficnqrnwkcrshohxpztyfsc` (`name`),
  KEY `idx_tqchtzsrwqztvvcryoqrxclvfzxwcdzeidav` (`handle`),
  KEY `idx_aicximpqeznaxmypfpwxsfidhvygckmtemmm` (`dateDeleted`),
  KEY `fk_ozcsalthvjgmzyltwrxuvbsuisidmyzfoiay` (`fieldLayoutId`),
  CONSTRAINT `fk_ozcsalthvjgmzyltwrxuvbsuisidmyzfoiay` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tzhkrneeoccbequxwejaxzjxyqsruvdpybeb` (`groupId`),
  CONSTRAINT `fk_ajlvncoeopxzdajxryturldknnkroudftlvb` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_siyqcqdgiefwlldsgmnedqltavulcqlysjtq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ylcwawxpattkkyioobqsstpneytucnznmkus` (`token`),
  KEY `idx_qooztzsfnkgbdfhtqeytoooldnrymefgsmkx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_upljkymllryfwazuuknecuskjyuqowdcibah` (`handle`),
  KEY `idx_wbmhuyidocrhyvxrxlepdvutfbnjjecvnoss` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bdusvkrqqfshilaawzkiaqqxwhxdvtevqqef` (`groupId`,`userId`),
  KEY `idx_pegaqcsnfgrzhdnwaibuwaujeobugjovlzbm` (`userId`),
  CONSTRAINT `fk_jgyfrhrewkiejtsrhwxxzxhfzgpjdaeoohqj` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdcrbegnfzdgmtswlaaqdvekgyuzcdvkajjh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ygmufeutltftwwdjttxcnclgrtbtmveukfle` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pxiwbftldkhsglrttqrugygifgewlhkdmxzc` (`permissionId`,`groupId`),
  KEY `idx_ylagvesdjuoyxzkrruhqvwhrsmpenqkjvevl` (`groupId`),
  CONSTRAINT `fk_vxqwmdbvwtzczymyjywegtvnpheeayirwqfz` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wbiuapcacafdysmrtutxoxcqfapijwdgkjfg` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lhejnacmhufuqlpdomwhuljhtzpmwkysdorr` (`permissionId`,`userId`),
  KEY `idx_fphyluuutofghggllgufbnijtafzbsqzfdxm` (`userId`),
  CONSTRAINT `fk_ackwjzpudpwmjhbruyenglbqdislafqvvmvk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gyatfxmziuxboocjkczxvpscvpzatngzepff` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_ugfyzlonaiyjdapapobrnndxxnzxkbhgmppu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fermtukndcyfjwcnrwalncwkfvjiaqpmqudw` (`active`),
  KEY `idx_gblkjxrljnlmqppzebzaumcdwnudjadydpys` (`locked`),
  KEY `idx_uberhgmgkcodeypsiofnpoxludhkdqcifegp` (`pending`),
  KEY `idx_ohnsltvbtpbgrthnzgpqfdfryaixbprrimrc` (`suspended`),
  KEY `idx_wmzsayzwtfsepnkyybxolpfmzjylyahsnhzz` (`verificationCode`),
  KEY `idx_lxadqscxavypaiubdovueqxdhtkbdzxptxao` (`email`),
  KEY `idx_czuooubceicjcfwagkkgegshfmedlphacqcy` (`username`),
  KEY `fk_scxvkvtgpdgvutkmqfyryuuedckpatfzhiie` (`photoId`),
  CONSTRAINT `fk_scxvkvtgpdgvutkmqfyryuuedckpatfzhiie` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xudfojkglkdlymlmabjyumvkgmyczpurvelq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cdhhqmkhwzuaqnzlvxshtzumzzfqziyknqpq` (`name`,`parentId`,`volumeId`),
  KEY `idx_lmslsxoivfqgnqbhyupmblcgrrfhvntuxcoc` (`parentId`),
  KEY `idx_feptfejqohzqokhmgcinfftcoabnwxiqjuzv` (`volumeId`),
  CONSTRAINT `fk_fyzdcoprqbwtftfgtlmlbyeifpgcwzzigfyn` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdzxhmqshyhdmsjtqskylbjetetgezzxbbla` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kvjwdkyvbvbpygxarftwuursgnkhppejpklr` (`name`),
  KEY `idx_mjvtnvfrmfseqodbyagzztcrbvjtrkgbpgnx` (`handle`),
  KEY `idx_uyedcrfcifigwpuxiqoqpiocyajfajoqvqzo` (`fieldLayoutId`),
  KEY `idx_infvwiliajjojivkbqjjnbkvxzlchkxudvkv` (`dateDeleted`),
  CONSTRAINT `fk_lrculucqiqhyqkxfsahmhhapkbaazcotysug` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eljkyvugtwpsartglmrgmypzwroruwvbktcg` (`userId`),
  CONSTRAINT `fk_fmfaubujsvndtewgxliisyhkvnrjizbyidou` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-08  4:35:07
-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (41,1,1,1,'pexels-tirachard-kumtanom-112571-347145-min.jpg','image',NULL,1920,1078,305097,NULL,NULL,NULL,'2024-08-08 03:49:35','2024-08-08 03:49:35','2024-08-08 03:49:35'),(44,1,1,1,'pexels-pixabay-33109-min.jpg','image',NULL,1920,1280,1720629,NULL,NULL,NULL,'2024-08-08 03:49:46','2024-08-08 03:49:46','2024-08-08 03:49:46'),(45,1,1,1,'pexels-felixmittermeier-957024-min.jpg','image',NULL,1920,1280,2068423,NULL,NULL,NULL,'2024-08-08 03:49:46','2024-08-08 03:49:46','2024-08-08 03:49:46'),(47,1,1,1,'pexels-matthew-montrone-230847-1179229-min.jpg','image',NULL,1920,2880,2990767,NULL,NULL,NULL,'2024-08-08 03:49:47','2024-08-08 03:49:47','2024-08-08 03:49:47'),(51,1,1,1,'pexels-eberhardgross-1366909.jpg','image',NULL,640,960,195246,NULL,NULL,NULL,'2024-08-08 04:14:00','2024-08-08 04:14:00','2024-08-08 04:14:00'),(52,1,1,1,'pexels-michael-block-1691617-3225517.jpg','image',NULL,640,800,221036,NULL,NULL,NULL,'2024-08-08 04:14:00','2024-08-08 04:14:00','2024-08-08 04:14:00'),(53,1,1,1,'pexels-luisdelrio-15286.jpg','image',NULL,640,427,169936,NULL,NULL,NULL,'2024-08-08 04:14:00','2024-08-08 04:14:00','2024-08-08 04:14:00');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (2,1,12,'2024-08-08 04:14:02',0,1),(34,1,13,'2024-08-08 03:49:51',0,1),(34,1,18,'2024-08-08 03:47:14',0,1),(35,1,17,'2024-08-08 04:14:02',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2024-08-08 02:22:42','2024-08-08 02:22:42','a9cff314-1bff-4be8-acde-00c4ff05c116'),(2,2,1,'Home','2024-08-08 03:28:32','2024-08-08 04:14:02','92b12c23-4437-4721-90c0-d8331a2239f5'),(3,3,1,'Home','2024-08-08 03:28:32','2024-08-08 03:28:32','98f8fbe5-285c-4fcc-8d98-d5a1a4e93a71'),(4,4,1,'Home','2024-08-08 03:28:44','2024-08-08 03:28:44','fea6fff3-009b-4a85-a36c-236a8726e3f0'),(6,14,1,'Home','2024-08-08 03:29:10','2024-08-08 03:29:10','ae0e000b-70bf-4027-9589-9711b837cf55'),(8,21,1,'Home','2024-08-08 03:29:30','2024-08-08 03:29:30','1bfabf65-a5a6-4b7e-9659-bf958c92c362'),(10,24,1,'Home','2024-08-08 03:29:48','2024-08-08 03:29:48','ceca9de3-c6c2-4c8c-a5b2-321cae6e006e'),(11,25,1,'Home','2024-08-08 03:36:58','2024-08-08 03:36:58','f419b57b-38c1-48a9-abdd-0250c17cea55'),(13,36,1,'Home','2024-08-08 03:39:37','2024-08-08 03:39:37','6c60bc7e-8e39-428f-a3ab-2c9678560e24'),(14,39,1,'Home','2024-08-08 03:47:14','2024-08-08 03:47:14','51871384-f64c-4b95-9b97-610b5f007845'),(15,41,1,'Pexels tirachard kumtanom 112571 347145 min','2024-08-08 03:49:35','2024-08-08 03:49:35','dfa7531c-dcbe-4127-97cb-a0ebc71adff4'),(17,44,1,'Pexels pixabay 33109 min','2024-08-08 03:49:46','2024-08-08 03:49:46','6009c082-8434-4bbc-b28e-d3f6bbc06f4b'),(18,45,1,'Pexels felixmittermeier 957024 min','2024-08-08 03:49:46','2024-08-08 03:49:46','508a6ebc-581e-4dd4-b648-fd134686068a'),(19,47,1,'Pexels matthew montrone 230847 1179229 min','2024-08-08 03:49:47','2024-08-08 03:49:47','b301eeb6-51b8-4e50-aac2-fa926e4e55de'),(20,48,1,'Home','2024-08-08 03:49:51','2024-08-08 03:49:51','9eede212-5367-497d-9f38-54f4953c4b26'),(21,51,1,'Pexels eberhardgross 1366909','2024-08-08 04:14:00','2024-08-08 04:14:00','2907b898-0b00-44da-8b4c-64dca091423a'),(22,52,1,'Pexels michael block 1691617 3225517','2024-08-08 04:14:00','2024-08-08 04:14:00','40add56f-b5f2-4d1a-9ba4-c37dd5d4b50e'),(23,53,1,'Pexels luisdelrio 15286','2024-08-08 04:14:00','2024-08-08 04:14:00','37ff1d70-a8d8-4187-9e05-7fa5d7b60c90'),(25,56,1,'Home','2024-08-08 04:14:02','2024-08-08 04:14:02','5cdd8baf-c14d-4a31-a30d-b9c18dff0cd1');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'edit','2024-08-08 04:14:00'),(2,1,1,NULL,'save','2024-08-08 04:14:02');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-08-08 02:22:42','2024-08-08 02:22:42',NULL,NULL,'f287d15c-26e6-4b74-bbd2-f141b3c121ef'),(2,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:28:32','2024-08-08 04:14:02',NULL,NULL,'01a1abd9-6772-4854-b2a0-df3e18e34fd2'),(3,2,NULL,1,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:28:32','2024-08-08 03:28:32',NULL,NULL,'8497076a-a78e-479e-a5d0-7fa462add7aa'),(4,2,NULL,2,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:28:44','2024-08-08 03:28:44',NULL,NULL,'e26ab125-55e1-4986-a82f-c289c456a4eb'),(6,NULL,NULL,NULL,1,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:28:54','2024-08-08 03:28:54',NULL,'2024-08-08 03:29:02','aeb0650b-9f6a-44cc-8d2c-bf57cfc7219b'),(7,NULL,NULL,NULL,1,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:02','2024-08-08 03:29:02',NULL,'2024-08-08 03:29:03','49816f28-920c-4bb7-8757-3e98e8e59c49'),(8,NULL,NULL,NULL,1,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:03','2024-08-08 03:29:03',NULL,'2024-08-08 03:29:09','86e207eb-f352-400a-b370-6341decd91ea'),(9,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:03','2024-08-08 03:29:03',NULL,'2024-08-08 03:29:09','e693cae6-834f-4e75-a2a9-67075999893b'),(12,NULL,NULL,NULL,1,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:10','2024-08-08 03:29:10',NULL,'2024-08-08 03:33:02','a0d626f9-6824-408a-909f-d31710351b32'),(13,NULL,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:10','2024-08-08 03:29:10',NULL,'2024-08-08 03:33:02','7144f723-6201-4561-b1c5-1fec54a99f37'),(14,2,NULL,3,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:29:10','2024-08-08 03:29:10',NULL,NULL,'75d93bc8-0750-4df4-a88b-4d9d0b65485b'),(15,12,NULL,4,1,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:10','2024-08-08 03:29:10',NULL,'2024-08-08 03:33:02','d390c834-e170-4f38-a733-f487e1598259'),(16,13,NULL,5,3,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:10','2024-08-08 03:29:10',NULL,'2024-08-08 03:33:02','786457c8-dd96-4164-8b89-4d3454a98555'),(18,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:26','2024-08-08 03:29:26',NULL,'2024-08-08 03:29:30','2e6a9b08-1b72-422a-b201-c9978558bd98'),(20,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:30','2024-08-08 03:29:30',NULL,'2024-08-08 03:33:02','65d47b2e-cea7-455a-b46e-630176e2e54a'),(21,2,NULL,6,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:29:30','2024-08-08 03:29:30',NULL,NULL,'43197ab5-85d6-4dc3-8b38-57befb1ee308'),(22,20,NULL,7,4,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:29:30','2024-08-08 03:29:30',NULL,'2024-08-08 03:33:02','fcf23825-5d23-4dad-a1e4-35ad98d2ce89'),(24,2,NULL,8,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:29:48','2024-08-08 03:29:48',NULL,NULL,'5bfef711-90dc-41d8-b4b7-c0b99d5e5bca'),(25,2,NULL,9,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:36:58','2024-08-08 03:36:58',NULL,NULL,'829e357e-40bc-48b9-a25e-0181473b5967'),(27,NULL,NULL,NULL,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:37:23','2024-08-08 03:37:23',NULL,'2024-08-08 03:37:28','d39a3748-7ba6-41e4-843a-e5defd68b955'),(28,NULL,NULL,NULL,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:37:28','2024-08-08 03:37:28',NULL,'2024-08-08 03:37:44','d66d739e-fa52-42a8-9280-70bb68083af5'),(29,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:37:28','2024-08-08 03:37:28',NULL,'2024-08-08 03:37:44','c01c9aed-a546-4e73-a204-c685ebfdc92d'),(30,NULL,NULL,NULL,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:37:44','2024-08-08 03:37:44',NULL,'2024-08-08 03:37:45','53bfd8c7-752e-45bf-bef0-bdfa90488e50'),(31,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:37:44','2024-08-08 03:37:44',NULL,'2024-08-08 03:37:45','f2ad8a3b-5899-47e0-a97b-f3d84ebcab4d'),(34,NULL,NULL,NULL,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:39:37','2024-08-08 03:49:51',NULL,NULL,'a1ce483a-1f64-4f26-9864-6c2cde60d3e7'),(35,NULL,NULL,NULL,7,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:39:37','2024-08-08 04:14:02',NULL,NULL,'d79ceb03-0fb5-400f-90b5-5d891965f47c'),(36,2,NULL,10,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:39:37','2024-08-08 03:39:37',NULL,NULL,'62b319ec-4c48-46c9-b76f-f0135890ea31'),(37,34,NULL,11,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:39:37','2024-08-08 03:39:37',NULL,NULL,'ad05d8a4-1da4-48c9-a06f-d97aedbf0faf'),(38,35,NULL,12,7,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:39:37','2024-08-08 03:39:37',NULL,NULL,'fe4d3812-8d39-4c92-8b76-755d4958f737'),(39,2,NULL,13,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:47:14','2024-08-08 03:47:14',NULL,NULL,'26521fe4-934c-4b39-9673-ff133d8fa9a4'),(40,34,NULL,14,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:47:14','2024-08-08 03:47:14',NULL,NULL,'04f4c38e-0b07-4ded-adea-ace51bcefc26'),(41,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 03:49:35','2024-08-08 03:49:35',NULL,NULL,'ac048e79-3fdc-47b1-90b2-a330a7a41879'),(44,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 03:49:46','2024-08-08 03:49:46',NULL,NULL,'23026e30-c1e5-4efd-8de8-7b403ad5f0af'),(45,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 03:49:46','2024-08-08 03:49:46',NULL,NULL,'856c7d65-e529-46fb-9c30-453c3d631c33'),(47,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 03:49:47','2024-08-08 03:49:47',NULL,NULL,'ec228f09-8200-4f82-9668-ef737c206fae'),(48,2,NULL,15,5,'craft\\elements\\Entry',1,0,'2024-08-08 03:49:51','2024-08-08 03:49:51',NULL,NULL,'46a2d894-4149-49d2-9a74-0aad99213695'),(49,34,NULL,16,6,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:49:51','2024-08-08 03:49:51',NULL,NULL,'43f702b2-a6f2-41f1-bc91-013a251ad258'),(50,35,NULL,17,7,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 03:49:51','2024-08-08 03:49:51',NULL,NULL,'9b18b476-ebbd-4b9e-a6c7-5eba0ad62e9e'),(51,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 04:14:00','2024-08-08 04:14:00',NULL,NULL,'77c8bf66-5cc5-4b07-8fcc-ae7209217edf'),(52,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 04:14:00','2024-08-08 04:14:00',NULL,NULL,'31f02b03-9d6b-4abf-9eca-f0c8233e6799'),(53,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-08 04:14:00','2024-08-08 04:14:00',NULL,NULL,'b66cfb0b-b543-43f4-82fe-19616b35aa19'),(56,2,NULL,18,5,'craft\\elements\\Entry',1,0,'2024-08-08 04:14:02','2024-08-08 04:14:02',NULL,NULL,'a6fb502f-36af-46b1-a275-6ce7cfb1bbba'),(57,35,NULL,19,7,'craft\\elements\\MatrixBlock',1,0,'2024-08-08 04:14:02','2024-08-08 04:14:02',NULL,NULL,'257f118d-1cc1-4fd1-82f5-61490f3ec4c7');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2024-08-08 02:22:42','2024-08-08 02:22:42','424a033f-94f6-40f2-b73e-d590649af667'),(2,2,1,'home','__home__',1,'2024-08-08 03:28:32','2024-08-08 03:28:32','85e56c7f-0b27-4aae-84da-c9eec662a387'),(3,3,1,'home','__home__',1,'2024-08-08 03:28:32','2024-08-08 03:28:32','c8afd0d6-27d0-4795-ae0c-e53e21e22ea6'),(4,4,1,'home','__home__',1,'2024-08-08 03:28:44','2024-08-08 03:28:44','0dc7f9ad-3fd1-4664-bc3d-158081e9d43e'),(6,6,1,NULL,NULL,1,'2024-08-08 03:28:54','2024-08-08 03:28:54','bc456dea-331f-4d31-86fe-ae07025a7ddf'),(7,7,1,NULL,NULL,1,'2024-08-08 03:29:02','2024-08-08 03:29:02','98fefd05-fc32-4135-9270-93cbcacadd3f'),(8,8,1,NULL,NULL,1,'2024-08-08 03:29:03','2024-08-08 03:29:03','57b4e96e-734a-4108-94c9-9c97a59914bd'),(9,9,1,NULL,NULL,1,'2024-08-08 03:29:03','2024-08-08 03:29:03','79fc0174-9a83-4e65-8e51-e16726580e61'),(12,12,1,NULL,NULL,1,'2024-08-08 03:29:10','2024-08-08 03:29:10','22ce338c-3b3c-4b82-a07b-6d4829901878'),(13,13,1,NULL,NULL,1,'2024-08-08 03:29:10','2024-08-08 03:29:10','7083bdfc-90bc-4e4e-8539-89d39fec1447'),(14,14,1,'home','__home__',1,'2024-08-08 03:29:10','2024-08-08 03:29:10','c5be7dd1-69a9-4177-99bd-aa88314bc0b8'),(15,15,1,NULL,NULL,1,'2024-08-08 03:29:10','2024-08-08 03:29:10','12fcda9a-44f7-472b-bb74-cca81842ea39'),(16,16,1,NULL,NULL,1,'2024-08-08 03:29:10','2024-08-08 03:29:10','0b3e9232-c31b-4bb0-bd6b-b1b8ccd273b0'),(18,18,1,NULL,NULL,1,'2024-08-08 03:29:26','2024-08-08 03:29:26','d8292447-aeed-46bf-bb28-f40ffcc93d01'),(20,20,1,NULL,NULL,1,'2024-08-08 03:29:30','2024-08-08 03:29:30','1e78f1fb-85a6-4e15-b924-df38d5e13d75'),(21,21,1,'home','__home__',1,'2024-08-08 03:29:30','2024-08-08 03:29:30','97c66722-e59c-48e8-a209-e8038f1820d0'),(22,22,1,NULL,NULL,1,'2024-08-08 03:29:30','2024-08-08 03:29:30','4efd59df-97b2-4088-ada3-7fc8a0a3ef5f'),(24,24,1,'home','__home__',1,'2024-08-08 03:29:48','2024-08-08 03:29:48','692435d2-8e8b-4b16-b02b-1248b0e5d438'),(25,25,1,'home','__home__',1,'2024-08-08 03:36:58','2024-08-08 03:36:58','5780530c-cb9f-4ac5-92f3-7104a1704a20'),(27,27,1,NULL,NULL,1,'2024-08-08 03:37:23','2024-08-08 03:37:23','8a25bdb4-be36-40bb-9b67-48cb94f1ec9d'),(28,28,1,NULL,NULL,1,'2024-08-08 03:37:28','2024-08-08 03:37:28','b8f1396e-df85-4cfe-8321-1a6e1e548101'),(29,29,1,NULL,NULL,1,'2024-08-08 03:37:28','2024-08-08 03:37:28','676d4c66-14f8-4d59-9492-4fe8276fc6e6'),(30,30,1,NULL,NULL,1,'2024-08-08 03:37:44','2024-08-08 03:37:44','281bce20-6a5b-4db6-b121-1573041885bb'),(31,31,1,NULL,NULL,1,'2024-08-08 03:37:44','2024-08-08 03:37:44','85d9b788-0edd-4ccf-8f90-bf67d0bc7c9e'),(34,34,1,NULL,NULL,1,'2024-08-08 03:39:37','2024-08-08 03:39:37','d116cd67-b416-40aa-b812-490b39e5ec28'),(35,35,1,NULL,NULL,1,'2024-08-08 03:39:37','2024-08-08 03:39:37','3ebd2e70-194b-4228-ad8a-e7e281e349c9'),(36,36,1,'home','__home__',1,'2024-08-08 03:39:37','2024-08-08 03:39:37','c3627cde-61a1-40f8-961e-ed9aa48577b8'),(37,37,1,NULL,NULL,1,'2024-08-08 03:39:37','2024-08-08 03:39:37','04c8960b-cfc7-48f3-8de2-25f59ddcd7fe'),(38,38,1,NULL,NULL,1,'2024-08-08 03:39:37','2024-08-08 03:39:37','1265ffe2-f97b-499e-8f74-18f7c55a1093'),(39,39,1,'home','__home__',1,'2024-08-08 03:47:14','2024-08-08 03:47:14','35d4686e-0418-4387-86f9-af13d0df8b15'),(40,40,1,NULL,NULL,1,'2024-08-08 03:47:14','2024-08-08 03:47:14','f2db1fe1-b38c-4b9f-91bb-8b938a5ce01a'),(41,41,1,NULL,NULL,1,'2024-08-08 03:49:35','2024-08-08 03:49:35','3451819e-fbd9-400a-ac82-1a84acf9d53d'),(44,44,1,NULL,NULL,1,'2024-08-08 03:49:46','2024-08-08 03:49:46','76af0af5-727c-49c6-820c-f51d6bc1e7b3'),(45,45,1,NULL,NULL,1,'2024-08-08 03:49:46','2024-08-08 03:49:46','c73fd21b-2706-4eac-9747-e8ca0ab0effe'),(47,47,1,NULL,NULL,1,'2024-08-08 03:49:47','2024-08-08 03:49:47','4a6b44da-1b7b-4c3b-84e6-bfd372741621'),(48,48,1,'home','__home__',1,'2024-08-08 03:49:51','2024-08-08 03:49:51','553c616a-8f28-439d-b31d-91c823b81bd8'),(49,49,1,NULL,NULL,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','1dc87fad-79e7-43af-a8d3-c2c1cd7480e4'),(50,50,1,NULL,NULL,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','21ed9fc5-0c29-4676-b07d-f21a60424d07'),(51,51,1,NULL,NULL,1,'2024-08-08 04:14:00','2024-08-08 04:14:00','1259abfa-c59a-4503-bb56-b2d40fa18078'),(52,52,1,NULL,NULL,1,'2024-08-08 04:14:00','2024-08-08 04:14:00','f2db2870-320a-4141-9b93-ffb51b48e977'),(53,53,1,NULL,NULL,1,'2024-08-08 04:14:00','2024-08-08 04:14:00','84847326-2c39-4d28-ad7f-e221e68b8450'),(56,56,1,'home','__home__',1,'2024-08-08 04:14:02','2024-08-08 04:14:02','a6bcb523-3b0f-4185-8b41-f39bce5eef97'),(57,57,1,NULL,NULL,1,'2024-08-08 04:14:02','2024-08-08 04:14:02','1864d349-546f-47a2-be28-3f2d6b2869ac');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:28:32','2024-08-08 03:28:32'),(3,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:28:32','2024-08-08 03:28:32'),(4,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:28:44','2024-08-08 03:28:44'),(14,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:29:10','2024-08-08 03:29:10'),(21,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:29:30','2024-08-08 03:29:30'),(24,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:29:48','2024-08-08 03:29:48'),(25,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:36:58','2024-08-08 03:36:58'),(36,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:39:37','2024-08-08 03:39:37'),(39,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:47:14','2024-08-08 03:47:14'),(48,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 03:49:51','2024-08-08 03:49:51'),(56,1,NULL,1,NULL,'2024-08-08 03:28:00',NULL,NULL,'2024-08-08 04:14:02','2024-08-08 04:14:02');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,5,'Home','home',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2024-08-08 03:28:32','2024-08-08 03:28:32',NULL,'22e61d75-7f6d-4940-a410-3021805e00ba');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2024-08-08 02:22:42','2024-08-08 02:22:42',NULL,'7d7aec54-3b8c-4f3c-a18c-35883a7ee404');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (20,5,12,12,0,1,'2024-08-08 03:36:58','2024-08-08 03:36:58','8d3870a1-7f38-4a9f-9165-8f437a4351f1'),(21,6,13,14,0,0,'2024-08-08 03:47:00','2024-08-08 03:47:00','26bdf42b-2843-443e-b7e1-898288b2810f'),(22,6,13,18,0,1,'2024-08-08 03:47:00','2024-08-08 03:47:00','9e182988-6110-4887-9881-b9cda54be1d9'),(23,6,13,13,0,2,'2024-08-08 03:47:00','2024-08-08 03:47:00','cf9fefd7-74f3-461d-aa7d-97c8b05b0eea'),(24,7,14,15,0,0,'2024-08-08 03:47:00','2024-08-08 03:47:00','eb63b785-1419-4514-8151-fd12fce12531'),(25,7,14,16,0,1,'2024-08-08 03:47:00','2024-08-08 03:47:00','978379b3-40cb-44d1-a361-a0e90620d56e'),(26,7,14,17,0,2,'2024-08-08 03:47:00','2024-08-08 03:47:00','b2307d41-e4e4-4b5f-9eb0-bd0367f9fd0a');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\MatrixBlock','2024-08-08 03:14:38','2024-08-08 03:14:38','2024-08-08 03:33:02','d00a0ac9-3f16-496f-8ed7-3438f4ac6af9'),(2,'craft\\elements\\Asset','2024-08-08 03:15:36','2024-08-08 03:15:36',NULL,'18d82626-8406-43ba-82d1-7f82bfd41aea'),(3,'craft\\elements\\MatrixBlock','2024-08-08 03:19:54','2024-08-08 03:19:54','2024-08-08 03:33:02','7dc341d2-a53e-49cf-80b1-d02d5b8548c5'),(4,'craft\\elements\\MatrixBlock','2024-08-08 03:19:54','2024-08-08 03:19:54','2024-08-08 03:33:02','d445cc14-cf93-46c6-8019-a8de666850b6'),(5,'craft\\elements\\Entry','2024-08-08 03:28:32','2024-08-08 03:28:32',NULL,'c655fdfd-55f6-41be-abbd-26d1eb6f5750'),(6,'craft\\elements\\MatrixBlock','2024-08-08 03:36:29','2024-08-08 03:36:29',NULL,'b319e26a-e400-4e30-a7ec-ee0e14c35f27'),(7,'craft\\elements\\MatrixBlock','2024-08-08 03:36:29','2024-08-08 03:36:29',NULL,'14a9a35a-adae-4b74-94a8-189f36d98839');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (2,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"58749a25-47d7-4044-8ca6-8690fcbeb72e\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\",\"attribute\":\"alt\",\"requirable\":true,\"class\":null,\"rows\":null,\"cols\":null,\"name\":null,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"19780490-24de-4516-81b8-4687ad5d4fab\",\"userCondition\":null,\"elementCondition\":null}]',1,'2024-08-08 03:15:36','2024-08-08 03:15:36','01a07fd9-324a-4cf0-96b3-983553c3609e'),(3,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"561ae88b-4ddf-40c8-aac8-83f231b412e0\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"1fc26d23-1a4a-4bae-a23c-2becbeec97ef\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"40564a18-1660-44ca-9c20-b14ccbd8d7ca\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"4fb76827-e92c-489d-a8cc-f2bc2a60be8a\"}]',1,'2024-08-08 03:19:54','2024-08-08 03:19:54','81420a66-ceab-4cf5-836c-b7445f3e5673'),(8,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"ffb530df-035c-49b8-b8b9-2c6bb0479271\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"d8b8c667-2c93-41af-8017-837fe0eceeeb\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1e84c5d8-6fa0-47af-9199-b5f76242b9a3\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"5a1c3767-0765-471c-9fda-c8bd81ea2a1e\"}]',1,'2024-08-08 03:31:05','2024-08-08 03:31:05','5b14b903-9a28-422a-93ed-05b5ac14ba48'),(9,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"49177bf3-fa81-4cb3-9249-ae948736ea80\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a8a0474b-cccf-4f66-aa74-6b76378579da\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"db45ac8a-e26f-4bb5-a095-7482428dcc96\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"06b4c9b8-2bed-47dc-a02a-043595ecbb49\"}]',1,'2024-08-08 03:31:05','2024-08-08 03:31:05','567a36e7-1950-4d65-aa4a-c48afa115c41'),(12,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"a85091ee-3357-4ca8-be54-be64d7ae0673\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8e136735-1722-4264-95a8-afaa303038ab\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"1cb1883a-4c9d-4d32-9386-210a71fbe719\"}]',1,'2024-08-08 03:36:58','2024-08-08 03:36:58','397229b9-131d-428a-ad85-5ee5c9911d13'),(13,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"349052f1-a2eb-4d43-8bcb-f1cde2443506\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"b17e3fa4-b66f-42e0-89d3-cc3f7de93740\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"c0e1f833-f300-4154-9c2b-86b8599d0667\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8e0a369a-d9c6-4dbc-b572-9575a85b1dac\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"0e8ae1b3-1f35-4c21-834f-9c8c316046dc\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ac60f42c-c1aa-41be-a488-4d28c6b6ec1f\"}]',1,'2024-08-08 03:47:00','2024-08-08 03:47:00','6917776a-74ce-4fff-a011-a1c66b327c81'),(14,7,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"5b83baf0-def4-4731-89fa-2582daf192d8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ab249b3f-99eb-4e73-9dcf-1c98e3914240\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"3307f79e-3bc0-4915-ad19-b9b3326f39ac\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"b1f2fd65-ae22-447c-9e55-00ee1d289053\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"3bd981f3-795e-4c73-93ec-26eda9eae618\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"d6dd6e70-c071-45bb-867c-42d874d4b3e2\"}]',1,'2024-08-08 03:47:00','2024-08-08 03:47:00','a3bbca68-adc3-4ad2-a307-cf889f9429e0');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (12,1,'Components','components','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":null,\"maxBlocks\":null,\"contentTable\":\"{{%matrixcontent_components}}\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null}','2024-08-08 03:36:28','2024-08-08 03:47:00','1cb1883a-4c9d-4d32-9386-210a71fbe719'),(13,NULL,'Hero Image','heroImage','matrixBlockType:dfe63ba6-923e-4be5-91f3-74717e874145',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-08-08 03:36:29','2024-08-08 03:47:00','ac60f42c-c1aa-41be-a488-4d28c6b6ec1f'),(14,NULL,'Heading','heading','matrixBlockType:dfe63ba6-923e-4be5-91f3-74717e874145','itadloce',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":500,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-08 03:36:29','2024-08-08 03:36:29','b17e3fa4-b66f-42e0-89d3-cc3f7de93740'),(15,NULL,'Heading','heading','matrixBlockType:acaeab4a-c75b-4a4b-8b0d-ce635d649fb2','oczjoork',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":500,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-08 03:36:29','2024-08-08 03:36:29','ab249b3f-99eb-4e73-9dcf-1c98e3914240'),(16,NULL,'Short Description','shortDescription','matrixBlockType:acaeab4a-c75b-4a4b-8b0d-ce635d649fb2','qmeakwxi',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":500,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-08 03:36:29','2024-08-08 03:36:29','b1f2fd65-ae22-447c-9e55-00ee1d289053'),(17,NULL,'Images','images','matrixBlockType:acaeab4a-c75b-4a4b-8b0d-ce635d649fb2',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-08-08 03:36:29','2024-08-08 03:47:00','d6dd6e70-c071-45bb-867c-42d874d4b3e2'),(18,NULL,'Short Text','shortText','matrixBlockType:dfe63ba6-923e-4be5-91f3-74717e874145','iqnkxidc',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":500,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"enlarged\"}','2024-08-08 03:47:00','2024-08-08 03:47:00','8e0a369a-d9c6-4dbc-b572-9575a85b1dac');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.11.1','4.5.3.0',0,'hycytsmjihlu','3@iqhwkqzgek','2024-08-08 02:22:42','2024-08-08 03:50:18','8392d53e-66a2-4ce7-adb3-75a17e17af44');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (34,2,12,4,NULL,'2024-08-08 03:39:37','2024-08-08 03:39:37'),(35,2,12,5,NULL,'2024-08-08 03:39:37','2024-08-08 03:39:37'),(37,36,12,4,NULL,'2024-08-08 03:39:37','2024-08-08 03:39:37'),(38,36,12,5,NULL,'2024-08-08 03:39:37','2024-08-08 03:39:37'),(40,39,12,4,NULL,'2024-08-08 03:47:14','2024-08-08 03:47:14'),(49,48,12,4,NULL,'2024-08-08 03:49:51','2024-08-08 03:49:51'),(50,48,12,5,NULL,'2024-08-08 03:49:51','2024-08-08 03:49:51'),(57,56,12,5,NULL,'2024-08-08 04:14:02','2024-08-08 04:14:02');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks_owners` VALUES (34,2,1),(35,2,2),(37,36,1),(38,36,2),(38,39,2),(40,39,1),(49,48,1),(49,56,1),(50,48,2),(57,56,2);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (4,12,6,'Hero','hero',1,'2024-08-08 03:36:29','2024-08-08 03:36:29','dfe63ba6-923e-4be5-91f3-74717e874145'),(5,12,7,'Image Carousel','imageCarousel',2,'2024-08-08 03:36:29','2024-08-08 03:36:29','acaeab4a-c75b-4a4b-8b0d-ce635d649fb2');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_components`
--

LOCK TABLES `matrixcontent_components` WRITE;
/*!40000 ALTER TABLE `matrixcontent_components` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_components` VALUES (1,27,1,'2024-08-08 03:37:23','2024-08-08 03:37:23','36b8ad0d-4687-45ec-89cb-143d41a66cd4',NULL,NULL,NULL,NULL),(2,28,1,'2024-08-08 03:37:28','2024-08-08 03:37:28','0422b3c4-0281-4538-91bf-c461d701b6f8','Hero Text',NULL,NULL,NULL),(3,29,1,'2024-08-08 03:37:28','2024-08-08 03:37:28','1ba2e9c6-dfee-41f7-b0ad-2aef23168f0f',NULL,NULL,NULL,NULL),(4,30,1,'2024-08-08 03:37:44','2024-08-08 03:37:44','911866ff-b3a3-4eda-9454-c536ac8a3abe','Hero Text',NULL,NULL,NULL),(5,31,1,'2024-08-08 03:37:44','2024-08-08 03:37:44','71510c66-d710-4403-a15f-ccf648b948e7',NULL,'The Image Carousel',NULL,NULL),(8,34,1,'2024-08-08 03:39:37','2024-08-08 03:49:51','d6f932d6-dea5-41c7-a789-a2ca947c2219','Hero Text',NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.'),(9,35,1,'2024-08-08 03:39:37','2024-08-08 04:14:02','96500ede-a246-459c-814a-b42cac30c090',NULL,'The Image Carousel','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.',NULL),(10,37,1,'2024-08-08 03:39:37','2024-08-08 03:39:37','b6fc9777-9678-455d-b7b5-a5ed6797013a','Hero Text',NULL,NULL,NULL),(11,38,1,'2024-08-08 03:39:37','2024-08-08 03:39:37','0a3468d8-7ff3-43f5-b4fa-39c75afcaefd',NULL,'The Image Carousel','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.',NULL),(12,40,1,'2024-08-08 03:47:14','2024-08-08 03:47:14','6fdbf455-90d7-4259-a561-d16e1489c560','Hero Text',NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.'),(15,49,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','83048caa-4872-4a54-8984-2ea1b59e07d3','Hero Text',NULL,NULL,'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.'),(16,50,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','ed942042-614a-4b6d-bec0-28ef46de2b42',NULL,'The Image Carousel','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.',NULL),(18,57,1,'2024-08-08 04:14:02','2024-08-08 04:14:02','54241be0-1e9a-4bff-9a86-e3eaf7719089',NULL,'The Image Carousel','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse elit risus, ultrices non orci a, pretium ultricies nulla. Etiam venenatis semper molestie.',NULL);
/*!40000 ALTER TABLE `matrixcontent_components` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','751e861b-c132-4be2-823c-3f24c7c16dde'),(2,'craft','m210121_145800_asset_indexing_changes','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','58a54f59-4773-47c5-8f52-ad1510dbe050'),(3,'craft','m210624_222934_drop_deprecated_tables','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','4c95c997-fe6c-46ac-b163-59718e3c8e64'),(4,'craft','m210724_180756_rename_source_cols','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','702becd9-9a8a-4321-8a1e-94811382b0e6'),(5,'craft','m210809_124211_remove_superfluous_uids','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','4ec995a0-326c-41b4-b68c-a421e09140ad'),(6,'craft','m210817_014201_universal_users','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','bc56671b-1076-45b1-97b9-4a7ab284e0b4'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','9d9ae42a-5937-481f-a117-6e1e91648493'),(8,'craft','m211115_135500_image_transformers','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','ac5fcba7-5834-4d3b-bbd0-c1d754bc3d2b'),(9,'craft','m211201_131000_filesystems','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','e2ff08b4-6c75-4fe7-a7ec-7400e0898d76'),(10,'craft','m220103_043103_tab_conditions','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','ee2d12e4-751e-4abb-88a6-056c729fc47c'),(11,'craft','m220104_003433_asset_alt_text','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','a310741c-705a-4aa3-b4ee-100d0ed9b529'),(12,'craft','m220123_213619_update_permissions','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','01a8a513-37f7-4138-af0c-c8c104a1fa70'),(13,'craft','m220126_003432_addresses','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','29b1ab11-2796-4625-8cc2-bd1f82d18f4c'),(14,'craft','m220209_095604_add_indexes','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','1c471ca7-88b3-47af-b37d-83b0e02aeb32'),(15,'craft','m220213_015220_matrixblocks_owners_table','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','8a28113f-5dde-4d2a-b91b-18fe361b5efb'),(16,'craft','m220214_000000_truncate_sessions','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','ab90a837-b2f3-442d-991d-39a5cd86ac9e'),(17,'craft','m220222_122159_full_names','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','e0e66498-bfb2-4598-9bea-fe2b64495f0f'),(18,'craft','m220223_180559_nullable_address_owner','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','f4cff71c-b3e5-4ba8-96b3-000956a64d1d'),(19,'craft','m220225_165000_transform_filesystems','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','87f36756-4b4b-4420-a56c-77d29bef800f'),(20,'craft','m220309_152006_rename_field_layout_elements','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','2c1c618e-816f-4d61-a34b-53ba1d1c5afe'),(21,'craft','m220314_211928_field_layout_element_uids','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','883690ce-47b0-4727-8a8d-e440e0f8c15e'),(22,'craft','m220316_123800_transform_fs_subpath','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','87d21bf4-88e8-47eb-a3f2-8365cbb57240'),(23,'craft','m220317_174250_release_all_jobs','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','d17a7a37-3afb-47fd-a5c1-cb7ed929cd11'),(24,'craft','m220330_150000_add_site_gql_schema_components','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','f350ad84-232f-4dcd-b186-b3f838f92413'),(25,'craft','m220413_024536_site_enabled_string','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','e6dbfeeb-d265-4b9f-93bb-530bac013a7c'),(26,'craft','m221027_160703_add_image_transform_fill','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','9bf435c5-7ef7-4d8d-a459-cc453806d4fc'),(27,'craft','m221028_130548_add_canonical_id_index','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','580a833c-c55e-49bc-8b32-f229e8e743ce'),(28,'craft','m221118_003031_drop_element_fks','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','8c80175e-c847-45b5-90c9-faf002d7070f'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','6ccb5ecf-8a32-4214-950e-97e6cc7b6e1a'),(30,'craft','m230226_013114_drop_plugin_license_columns','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','6f6e5803-08bb-4080-bd1b-21e7d18f7b32'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','9d423035-9b03-450f-a561-e7b066fed8fa'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','35c52873-4ebf-4228-9218-9a9d6b2a6ac9'),(33,'craft','m230710_162700_element_activity','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','23f1a1f0-03c5-4d52-87bb-4e80fcbc99fe'),(34,'craft','m230820_162023_fix_cache_id_type','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','cbb1d08f-4743-4e07-8d8d-39d88464fe67'),(35,'craft','m230826_094050_fix_session_id_type','2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 02:22:43','a53156ef-6631-4c11-91d3-f96a08e75260');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1723089018'),('email.fromEmail','\"sample@email.com\"'),('email.fromName','\"Imagic Craft Site\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elementCondition','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.autocapitalize','true'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.autocomplete','false'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.autocorrect','true'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.class','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.disabled','false'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.elementCondition','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.id','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.inputType','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.instructions','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.label','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.max','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.min','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.name','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.orientation','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.placeholder','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.readonly','false'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.requirable','false'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.size','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.step','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.tip','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.title','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.uid','\"a85091ee-3357-4ca8-be54-be64d7ae0673\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.userCondition','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.warning','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.0.width','100'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.elementCondition','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.fieldUid','\"1cb1883a-4c9d-4d32-9386-210a71fbe719\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.instructions','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.label','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.required','false'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.tip','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.uid','\"8e136735-1722-4264-95a8-afaa303038ab\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.userCondition','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.warning','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.elements.1.width','100'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.name','\"Content\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.uid','\"397229b9-131d-428a-ad85-5ee5c9911d13\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.fieldLayouts.c655fdfd-55f6-41be-abbd-26d1eb6f5750.tabs.0.userCondition','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.handle','\"home\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.hasTitleField','false'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.name','\"Home\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.section','\"d867311c-10fa-4995-a2dd-9187d62d1f2a\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.showStatusField','true'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.slugTranslationKeyFormat','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.slugTranslationMethod','\"site\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.sortOrder','1'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.titleFormat','\"{section.name|raw}\"'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.titleTranslationKeyFormat','null'),('entryTypes.22e61d75-7f6d-4940-a410-3021805e00ba.titleTranslationMethod','\"site\"'),('fieldGroups.7d7aec54-3b8c-4f3c-a18c-35883a7ee404.name','\"Common\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.columnSuffix','null'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.contentColumnType','\"string\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.fieldGroup','\"7d7aec54-3b8c-4f3c-a18c-35883a7ee404\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.handle','\"components\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.instructions','null'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.name','\"Components\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.searchable','false'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.settings.contentTable','\"{{%matrixcontent_components}}\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.settings.maxBlocks','null'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.settings.minBlocks','null'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.settings.propagationKeyFormat','null'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.settings.propagationMethod','\"all\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.translationKeyFormat','null'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.translationMethod','\"site\"'),('fields.1cb1883a-4c9d-4d32-9386-210a71fbe719.type','\"craft\\\\fields\\\\Matrix\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"uploads\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"uploads\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.field','\"1cb1883a-4c9d-4d32-9386-210a71fbe719\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elementCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.fieldUid','\"ab249b3f-99eb-4e73-9dcf-1c98e3914240\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.label','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.required','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.tip','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.uid','\"5b83baf0-def4-4731-89fa-2582daf192d8\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.warning','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.0.width','100'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.fieldUid','\"b1f2fd65-ae22-447c-9e55-00ee1d289053\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.label','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.required','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.tip','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.uid','\"3307f79e-3bc0-4915-ad19-b9b3326f39ac\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.warning','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.1.width','100'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.fieldUid','\"d6dd6e70-c071-45bb-867c-42d874d4b3e2\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.label','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.required','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.tip','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.uid','\"3bd981f3-795e-4c73-93ec-26eda9eae618\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.warning','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.elements.2.width','100'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.name','\"Content\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.uid','\"a3bbca68-adc3-4ad2-a307-cf889f9429e0\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fieldLayouts.14a9a35a-adae-4b74-94a8-189f36d98839.tabs.0.userCondition','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.columnSuffix','\"oczjoork\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.contentColumnType','\"text\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.fieldGroup','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.handle','\"heading\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.instructions','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.name','\"Heading\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.searchable','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.byteLimit','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.charLimit','500'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.code','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.columnType','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.initialRows','4'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.multiline','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.placeholder','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.settings.uiMode','\"normal\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.translationKeyFormat','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.translationMethod','\"none\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.ab249b3f-99eb-4e73-9dcf-1c98e3914240.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.columnSuffix','\"qmeakwxi\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.contentColumnType','\"text\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.fieldGroup','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.handle','\"shortDescription\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.instructions','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.name','\"Short Description\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.searchable','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.byteLimit','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.charLimit','500'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.code','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.columnType','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.initialRows','4'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.multiline','true'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.placeholder','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.settings.uiMode','\"normal\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.translationKeyFormat','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.translationMethod','\"none\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.b1f2fd65-ae22-447c-9e55-00ee1d289053.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.columnSuffix','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.contentColumnType','\"string\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.fieldGroup','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.handle','\"images\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.instructions','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.name','\"Images\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.searchable','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.allowedKinds.0','\"image\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.allowSelfRelations','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.allowSubfolders','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.allowUploads','true'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.branchLimit','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.defaultUploadLocationSource','\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.localizeRelations','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.maintainHierarchy','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.maxRelations','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.minRelations','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.previewMode','\"full\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.restrictedLocationSource','\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.restrictFiles','true'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.restrictLocation','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.selectionLabel','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.showSiteMenu','true'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.showUnpermittedFiles','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.sources.0','\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.targetSiteId','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.validateRelatedElements','false'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.settings.viewMode','\"list\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.translationKeyFormat','null'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.translationMethod','\"site\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.fields.d6dd6e70-c071-45bb-867c-42d874d4b3e2.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.handle','\"imageCarousel\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.name','\"Image Carousel\"'),('matrixBlockTypes.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2.sortOrder','2'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.field','\"1cb1883a-4c9d-4d32-9386-210a71fbe719\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elementCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.fieldUid','\"b17e3fa4-b66f-42e0-89d3-cc3f7de93740\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.label','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.required','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.tip','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.uid','\"349052f1-a2eb-4d43-8bcb-f1cde2443506\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.warning','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.0.width','100'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.fieldUid','\"8e0a369a-d9c6-4dbc-b572-9575a85b1dac\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.label','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.required','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.tip','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.uid','\"c0e1f833-f300-4154-9c2b-86b8599d0667\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.warning','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.1.width','100'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.fieldUid','\"ac60f42c-c1aa-41be-a488-4d28c6b6ec1f\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.label','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.required','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.tip','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.uid','\"0e8ae1b3-1f35-4c21-834f-9c8c316046dc\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.warning','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.elements.2.width','100'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.name','\"Content\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.uid','\"6917776a-74ce-4fff-a011-a1c66b327c81\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fieldLayouts.b319e26a-e400-4e30-a7ec-ee0e14c35f27.tabs.0.userCondition','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.columnSuffix','\"iqnkxidc\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.contentColumnType','\"text\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.fieldGroup','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.handle','\"shortText\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.instructions','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.name','\"Short Text\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.searchable','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.byteLimit','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.charLimit','500'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.code','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.columnType','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.initialRows','4'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.multiline','true'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.placeholder','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.translationKeyFormat','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.translationMethod','\"none\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.8e0a369a-d9c6-4dbc-b572-9575a85b1dac.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.columnSuffix','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.contentColumnType','\"string\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.fieldGroup','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.handle','\"heroImage\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.instructions','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.name','\"Hero Image\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.searchable','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.allowedKinds.0','\"image\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.allowSelfRelations','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.allowSubfolders','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.allowUploads','true'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.branchLimit','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.defaultUploadLocationSource','\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.localizeRelations','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.maintainHierarchy','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.maxRelations','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.minRelations','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.previewMode','\"full\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.restrictedLocationSource','\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.restrictFiles','true'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.restrictLocation','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.selectionLabel','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.showSiteMenu','true'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.showUnpermittedFiles','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.sources.0','\"volume:e52503d0-9bc0-4f71-bcdc-23e8f53a1e58\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.targetSiteId','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.validateRelatedElements','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.settings.viewMode','\"list\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.translationKeyFormat','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.translationMethod','\"site\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.columnSuffix','\"itadloce\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.contentColumnType','\"text\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.fieldGroup','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.handle','\"heading\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.instructions','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.name','\"Heading\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.searchable','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.byteLimit','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.charLimit','500'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.code','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.columnType','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.initialRows','4'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.multiline','false'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.placeholder','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.settings.uiMode','\"normal\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.translationKeyFormat','null'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.translationMethod','\"none\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.fields.b17e3fa4-b66f-42e0-89d3-cc3f7de93740.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.handle','\"hero\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.name','\"Hero\"'),('matrixBlockTypes.dfe63ba6-923e-4be5-91f3-74717e874145.sortOrder','1'),('meta.__names__.1cb1883a-4c9d-4d32-9386-210a71fbe719','\"Components\"'),('meta.__names__.22e61d75-7f6d-4940-a410-3021805e00ba','\"Home\"'),('meta.__names__.2d1f5733-3df1-4570-a0ed-af51908a8a2b','\"Imagic Craft Site\"'),('meta.__names__.7d7aec54-3b8c-4f3c-a18c-35883a7ee404','\"Common\"'),('meta.__names__.8e0a369a-d9c6-4dbc-b572-9575a85b1dac','\"Short Text\"'),('meta.__names__.8eb5908a-32aa-46ea-a516-6e2257cf2fed','\"Imagic Craft Site\"'),('meta.__names__.ab249b3f-99eb-4e73-9dcf-1c98e3914240','\"Heading\"'),('meta.__names__.ac60f42c-c1aa-41be-a488-4d28c6b6ec1f','\"Hero Image\"'),('meta.__names__.acaeab4a-c75b-4a4b-8b0d-ce635d649fb2','\"Image Carousel\"'),('meta.__names__.b17e3fa4-b66f-42e0-89d3-cc3f7de93740','\"Heading\"'),('meta.__names__.b1f2fd65-ae22-447c-9e55-00ee1d289053','\"Short Description\"'),('meta.__names__.d6dd6e70-c071-45bb-867c-42d874d4b3e2','\"Images\"'),('meta.__names__.d867311c-10fa-4995-a2dd-9187d62d1f2a','\"Home\"'),('meta.__names__.dfe63ba6-923e-4be5-91f3-74717e874145','\"Hero\"'),('meta.__names__.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58','\"Images\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.defaultPlacement','\"end\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.enableVersioning','true'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.handle','\"home\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.name','\"Home\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.propagationMethod','\"all\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.siteSettings.8eb5908a-32aa-46ea-a516-6e2257cf2fed.enabledByDefault','true'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.siteSettings.8eb5908a-32aa-46ea-a516-6e2257cf2fed.hasUrls','true'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.siteSettings.8eb5908a-32aa-46ea-a516-6e2257cf2fed.template','\"pages/home.twig\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.siteSettings.8eb5908a-32aa-46ea-a516-6e2257cf2fed.uriFormat','\"__home__\"'),('sections.d867311c-10fa-4995-a2dd-9187d62d1f2a.type','\"single\"'),('siteGroups.2d1f5733-3df1-4570-a0ed-af51908a8a2b.name','\"Imagic Craft Site\"'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.handle','\"default\"'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.hasUrls','true'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.language','\"en-US\"'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.name','\"Imagic Craft Site\"'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.primary','true'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.siteGroup','\"2d1f5733-3df1-4570-a0ed-af51908a8a2b\"'),('sites.8eb5908a-32aa-46ea-a516-6e2257cf2fed.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Imagic Craft Site\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elementCondition','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.autocapitalize','true'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.autocomplete','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.autocorrect','true'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.class','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.disabled','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.elementCondition','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.id','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.inputType','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.instructions','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.label','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.max','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.min','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.name','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.orientation','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.placeholder','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.readonly','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.requirable','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.size','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.step','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.tip','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.title','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.uid','\"58749a25-47d7-4044-8ca6-8690fcbeb72e\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.userCondition','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.warning','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.0.width','100'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.attribute','\"alt\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.class','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.cols','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.disabled','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.elementCondition','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.id','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.instructions','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.label','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.name','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.orientation','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.placeholder','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.readonly','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.requirable','true'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.required','false'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.rows','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.tip','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.title','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.uid','\"19780490-24de-4516-81b8-4687ad5d4fab\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.userCondition','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.warning','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.elements.1.width','100'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.name','\"Content\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.uid','\"01a07fd9-324a-4cf0-96b3-983553c3609e\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fieldLayouts.18d82626-8406-43ba-82d1-7f82bfd41aea.tabs.0.userCondition','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.fs','\"uploads\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.handle','\"images\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.name','\"Images\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.sortOrder','1'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.titleTranslationKeyFormat','null'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.titleTranslationMethod','\"site\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.transformFs','\"\"'),('volumes.e52503d0-9bc0-4f71-bcdc-23e8f53a1e58.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (5,13,34,NULL,41,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','94188137-85e1-4a34-8c46-177d2eab3518'),(6,17,35,NULL,44,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','d0bd1c73-64ca-4a6c-8c4a-dc294797f69c'),(7,17,35,NULL,45,2,'2024-08-08 03:49:51','2024-08-08 03:49:51','22a6a570-3068-4fbb-a102-db5349298925'),(8,17,35,NULL,47,3,'2024-08-08 03:49:51','2024-08-08 03:49:51','49897e18-c8a0-43b4-b286-a4299ddf66c5'),(9,13,49,NULL,41,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','98829a39-0c3f-41de-9e96-7b8ce2f8efe2'),(10,17,50,NULL,44,1,'2024-08-08 03:49:51','2024-08-08 03:49:51','4ded6e0b-4435-4872-b47a-14de3c47552f'),(11,17,50,NULL,45,2,'2024-08-08 03:49:51','2024-08-08 03:49:51','8542c3ee-6c92-49e6-8a5e-31a127f04fdb'),(12,17,50,NULL,47,3,'2024-08-08 03:49:51','2024-08-08 03:49:51','81431b5f-b4fa-4863-9252-fc3e1457fb9f'),(19,17,35,NULL,51,4,'2024-08-08 04:14:02','2024-08-08 04:14:02','0c4a8104-28b7-4a26-b542-b1cc070c1456'),(20,17,35,NULL,52,5,'2024-08-08 04:14:02','2024-08-08 04:14:02','becdc94d-5ade-40f8-9bc6-b40911ff22a0'),(21,17,35,NULL,53,6,'2024-08-08 04:14:02','2024-08-08 04:14:02','5bd063cb-d4dd-45a2-8a1f-6db717a54a44'),(22,17,57,NULL,44,1,'2024-08-08 04:14:02','2024-08-08 04:14:02','b0a01695-7119-404a-850f-b007ebb46c9f'),(23,17,57,NULL,45,2,'2024-08-08 04:14:02','2024-08-08 04:14:02','e0f2ddc0-c133-4c0f-a6e4-8ea559463699'),(24,17,57,NULL,47,3,'2024-08-08 04:14:02','2024-08-08 04:14:02','41d88f7c-de1e-401b-b872-8ea4540c8994'),(25,17,57,NULL,51,4,'2024-08-08 04:14:02','2024-08-08 04:14:02','0e9383b1-a7d4-431f-a6be-e4840743b140'),(26,17,57,NULL,52,5,'2024-08-08 04:14:02','2024-08-08 04:14:02','449ecf46-56aa-4875-b980-d8c835227f21'),(27,17,57,NULL,53,6,'2024-08-08 04:14:02','2024-08-08 04:14:02','19555c20-814e-4c2e-8e0c-79f29ab1c1cf');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,NULL),(3,2,1,3,'Applied “Draft 1”'),(4,12,1,1,NULL),(5,13,1,1,NULL),(6,2,1,4,'Applied “Draft 1”'),(7,20,1,1,NULL),(8,2,1,5,'Applied “Draft 1”'),(9,2,1,6,NULL),(10,2,1,7,'Applied “Draft 1”'),(11,34,1,1,NULL),(12,35,1,1,NULL),(13,2,1,8,''),(14,34,1,2,NULL),(15,2,1,9,'Applied “Draft 1”'),(16,34,1,3,NULL),(17,35,1,2,NULL),(18,2,1,10,'Applied “Draft 1”'),(19,35,1,3,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' sample email com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' nath sdev '),(2,'slug',0,1,' home '),(2,'title',0,1,' home '),(12,'slug',0,1,''),(13,'slug',0,1,''),(20,'slug',0,1,''),(34,'slug',0,1,''),(35,'slug',0,1,''),(41,'alt',0,1,''),(41,'extension',0,1,' jpg '),(41,'filename',0,1,' pexels tirachard kumtanom 112571 347145 min jpg '),(41,'kind',0,1,' image '),(41,'slug',0,1,''),(41,'title',0,1,' pexels tirachard kumtanom 112571 347145 min '),(44,'alt',0,1,''),(44,'extension',0,1,' jpg '),(44,'filename',0,1,' pexels pixabay 33109 min jpg '),(44,'kind',0,1,' image '),(44,'slug',0,1,''),(44,'title',0,1,' pexels pixabay 33109 min '),(45,'alt',0,1,''),(45,'extension',0,1,' jpg '),(45,'filename',0,1,' pexels felixmittermeier 957024 min jpg '),(45,'kind',0,1,' image '),(45,'slug',0,1,''),(45,'title',0,1,' pexels felixmittermeier 957024 min '),(47,'alt',0,1,''),(47,'extension',0,1,' jpg '),(47,'filename',0,1,' pexels matthew montrone 230847 1179229 min jpg '),(47,'kind',0,1,' image '),(47,'slug',0,1,''),(47,'title',0,1,' pexels matthew montrone 230847 1179229 min '),(51,'alt',0,1,''),(51,'extension',0,1,' jpg '),(51,'filename',0,1,' pexels eberhardgross 1366909 jpg '),(51,'kind',0,1,' image '),(51,'slug',0,1,''),(51,'title',0,1,' pexels eberhardgross 1366909 '),(52,'alt',0,1,''),(52,'extension',0,1,' jpg '),(52,'filename',0,1,' pexels michael block 1691617 3225517 jpg '),(52,'kind',0,1,' image '),(52,'slug',0,1,''),(52,'title',0,1,' pexels michael block 1691617 3225517 '),(53,'alt',0,1,''),(53,'extension',0,1,' jpg '),(53,'filename',0,1,' pexels luisdelrio 15286 jpg '),(53,'kind',0,1,' image '),(53,'slug',0,1,''),(53,'title',0,1,' pexels luisdelrio 15286 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'all','end',NULL,'2024-08-08 03:28:32','2024-08-08 03:28:32',NULL,'d867311c-10fa-4995-a2dd-9187d62d1f2a');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','pages/home.twig',1,'2024-08-08 03:28:32','2024-08-08 03:28:32','00351b93-97ac-4375-bcd7-13f3a2f2daa8');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Imagic Craft Site','2024-08-08 02:22:42','2024-08-08 02:22:42',NULL,'2d1f5733-3df1-4570-a0ed-af51908a8a2b');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','Imagic Craft Site','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-08-08 02:22:42','2024-08-08 02:22:42',NULL,'8eb5908a-32aa-46ea-a516-6e2257cf2fed');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'nath-sdev',NULL,NULL,NULL,'sample@email.com','$2y$13$6gOnVE45hMuHIeer2Qnsf./SiOlTXr2xmtHLpRSaOsjGUYr9q0Rl.','2024-08-08 03:13:20',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-08-08 02:22:43','2024-08-08 02:22:43','2024-08-08 03:13:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images','','2024-08-08 03:15:36','2024-08-08 03:15:36','142377e3-865b-49d6-81c6-0d80c02a75fb');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,2,'Images','images','uploads','','','site',NULL,1,'2024-08-08 03:15:36','2024-08-08 03:15:36',NULL,'e52503d0-9bc0-4f71-bcdc-23e8f53a1e58');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2024-08-08 03:13:20','2024-08-08 03:13:20','79c873ef-1814-4c63-a7d6-acd19ba6b945'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-08-08 03:13:20','2024-08-08 03:13:20','9718f956-c959-436e-9fdd-6e9001c0dea3'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-08-08 03:13:20','2024-08-08 03:13:20','9aa560fa-9509-4c06-857e-dda1b84b7d4c'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2024-08-08 03:13:20','2024-08-08 03:13:20','3b1db295-73c6-4758-b933-cdd8463a6f7d');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-08  4:35:07
